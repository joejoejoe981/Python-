import scrapy
from scrapy.exceptions import CloseSpider
from ..items import mobile01Item
class Moblie01Spider(scrapy.Spider):
    
    name = 'mobile01'
    allowed_domains = ['www.mobile01.com/']
    start_urls = []
    for i in range(10):
        start_urls.append('https://www.mobile01.com/category.php?id='+str(i+1)) 
        
    def parse(self, response):
        items = mobile01Item()
        for q in response.css('div.item'):
            items['title']=q.css('h3::text').extract_first()
            items['content']=q.css('p::text').extract_first()
            items['link']=q.css('a::attr(href)').extract_first()
            yield(items)

        raise  CloseSpider('close it')